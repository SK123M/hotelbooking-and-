package com.example.hotel_clg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
