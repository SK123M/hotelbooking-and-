import 'package:flutter/material.dart';
import 'package:hotel_clg/admin/create_room_model.dart';
import 'package:hotel_clg/login_screen_design.dart';
import 'package:hotel_clg/user/book_room_model.dart';
import 'package:hotel_clg/user/message_model.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await DataModelClass().createStudentData();
  await MessageModel().createStudentData();
  await CreateRoomModel().createRoom();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: LoginScreenDesign()
    );
  }
}
