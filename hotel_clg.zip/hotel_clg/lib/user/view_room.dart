import 'package:flutter/material.dart';
import 'package:hotel_clg/admin/create_room_model.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/user/book_room_model.dart';
import 'package:hotel_clg/user/payment_page.dart';

class ViewRoomScreen extends StatefulWidget {
  String title;
  String rent;
  String description;
  String image;
  String location;

  ViewRoomScreen(
      {super.key,
      required this.title,
      required this.location,
      required this.rent,
      required this.description,
      required this.image});

  @override
  State<ViewRoomScreen> createState() => _ViewRoomScreenState();
}

class _ViewRoomScreenState extends State<ViewRoomScreen> {
  final TextEditingController roomTypeTextCntrl = TextEditingController();
  final TextEditingController locationTextCntrl = TextEditingController();
  final TextEditingController dateTimeTextCntrl = TextEditingController();
  final TextEditingController checkinTextCntrl = TextEditingController();
  final TextEditingController checkOutTextCntrl = TextEditingController();
  final TextEditingController amountTextCntrl = TextEditingController();
  final TextEditingController daysControler = TextEditingController();

  DataModelClass _model = DataModelClass();
  CreateRoomModel _roomModel = CreateRoomModel();

  List<String> roomType = [
    'Single Bed Room',
    'Double Bed Room',
    'Deluxe Rooms',
    'Luxury Rooms',
  ];

  int selectRoom = 0;


  List<String> locationlist = [
    'Chennai',
    'Vellore',
    'ECR - Chennai',
    'Bangalore',
  ];

  int selectLoc = 0;


  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();

  Future<void> _selectDate(
      BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        // Format the selected date however you prefer
        controller.text = "${picked.toLocal()}".split(' ')[0];
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );

    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
        // Format the selected time however you prefer
        dateTimeTextCntrl.text += " ${picked.format(context)}";
      });
    }
  }

  Future<void> _initData() async {
    await _model.createStudentData();
    await _roomModel.createRoom();// Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model
        .saveData();

    _roomModel.saveData();// Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: true,
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                    height: 150,
                    width: 250,
                    child: Image.asset(
                      widget.image,
                      fit: BoxFit.cover,
                    )),
              ),
              SizedBox(
                height: 20,
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.location,
                      style: CommonStyles.blue14900(),
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.star,
                          color: Colors.orange,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.orange,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.orange,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.orange,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.orange,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "About Rooms",
                    style: CommonStyles.blue14900(),
                  ),
                  ElevatedButton(
                      onPressed: () {},
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 10),
                        child: Text("₹ ${widget.rent}",
                            style: CommonStyles
                                .whiteText15BoldW500()),
                      ),
                      style: ButtonStyle(
                          backgroundColor:
                          MaterialStateProperty.all(
                              Colors.green),
                          shape: MaterialStateProperty.all<
                              RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                  borderRadius:
                                  BorderRadius.circular(
                                      12.0),
                                  side: BorderSide(
                                      color: Colors.blue))))),

                ],
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                widget.description,
                style: CommonStyles.black12(),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Booking Details :-",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose Room Type",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              ListView.builder(
                  itemCount: roomType.length,
                  shrinkWrap: true,
                  primary: false,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            selectRoom = index;
                            roomTypeTextCntrl.text = roomType[index];
                          });
                        },
                        child: Card(
                          shape: selectRoom == index
                              ? RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side:
                                      BorderSide(width: 1, color: Colors.blue))
                              : null,
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 10),
                            child: Row(
                              children: [
                                IconButton(
                                    onPressed: () {},
                                    icon: Icon(
                                      Icons.hotel,
                                      color: Colors.blue,
                                    )),
                                SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  roomType[index],
                                  style: selectRoom == index ? CommonStyles.blue13900() : CommonStyles.black13(),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
              SizedBox(
                height: 20,
              ),
              Text(
                "Selected Room Type",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                readOnly: true,
                controller: roomTypeTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Room Type",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Choose Room Location",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 80,
                child: ListView.builder(
                    itemCount: locationlist.length,
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    physics: BouncingScrollPhysics(),
                    primary: false,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              selectLoc = index;
                              locationTextCntrl.text = locationlist[index];
                            });
                          },
                          child: Card(
                            shape: selectLoc == index
                                ? RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side:
                                BorderSide(width: 1, color: Colors.blue))
                                : null,
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 10),
                              child: Row(
                                children: [
                                  IconButton(
                                      onPressed: () {},
                                      icon: Icon(
                                        Icons.home_work_outlined,
                                        color: Colors.blue,
                                      )),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    locationlist[index],
                                    style: selectLoc == index ? CommonStyles.blue13900() : CommonStyles.black13(),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Location",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                readOnly: true,
                controller: locationTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Location",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Date and Time",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: dateTimeTextCntrl,
                style: CommonStyles.black13thin(),
                onTap: () {
                  _selectDate(context, dateTimeTextCntrl);
                },
                readOnly: true,
                decoration: InputDecoration(
                  hintText: "Date and Time",
                  hintStyle: CommonStyles.black13thin(),
                  prefixIcon: Icon(Icons.calendar_today),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(13),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Check in",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: checkinTextCntrl,
                style: CommonStyles.black13thin(),
                onTap: () {
                  _selectDate(context, checkinTextCntrl);
                },
                readOnly: true,
                decoration: InputDecoration(
                  hintText: "Check in",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Check Out",
                style: CommonStyles.blue14900(),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                onTap: () {
                  _selectDate(context, checkOutTextCntrl);
                },
                readOnly: true,
                controller: checkOutTextCntrl,
                style: CommonStyles.black13thin(),
                decoration: InputDecoration(
                  hintText: "Check Out",
                  labelStyle: CommonStyles.black13thin(),
                  hintStyle: CommonStyles.black13thin(),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(13)),
                ),
              ),
              SizedBox(
                height: 20,
              ),
           checkinTextCntrl.text.isNotEmpty && checkOutTextCntrl.text.isNotEmpty ?
           Column(
crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Amount",
                    style: CommonStyles.blue14900(),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    readOnly: true,



                  //  controller: amountTextCntrl,
                    initialValue:
                    roomTypeTextCntrl.text == "Single Bed Room"? "2500" :
                    roomTypeTextCntrl.text == "Double Bed Room"? "3500" :
                    roomTypeTextCntrl.text ==  'Deluxe Rooms'? "4500" :
                    roomTypeTextCntrl.text ==  'Luxury Rooms'? "6000" : '2500'

                    ,
                    style: CommonStyles.black13thin(),
                    decoration: InputDecoration(
                      hintText: "Amount",

                      labelStyle: CommonStyles.black13thin(),
                      hintStyle: CommonStyles.black13thin(),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "No of Days",
                    style: CommonStyles.blue14900(),
                  ),
                  SizedBox(
                    height: 10,
                  ),



                  TextFormField(
                    initialValue: "1",
readOnly: true,
                //    controller: daysControler,
                    style: CommonStyles.black13thin(),
                    decoration: InputDecoration(
                      hintText: "No of Days",
                      labelStyle: CommonStyles.black13thin(),
                      hintStyle: CommonStyles.black13thin(),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ],
              ) : Container(),
              SizedBox(
                height: 30,
              ),
              ElevatedButton(onPressed: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => PaymentPage(title: widget.title, img: widget.image, des: widget.description)));
              }, child:Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 10, horizontal: 50),
                child: Text("Make Payment",
                    style: CommonStyles.whiteText18BoldW500()),
              ),
                  style: ButtonStyle(
                      backgroundColor:
                      MaterialStateProperty.all(Colors.green),
                      shape:
                      MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(color: Colors.blue)))) ),
              SizedBox(
                height: 30,
              ),
              Center(
                child: ElevatedButton(
                    onPressed: () async {
                      if (roomTypeTextCntrl.text != null &&
                          roomTypeTextCntrl.text.isNotEmpty &&
                          dateTimeTextCntrl.text != null &&
                          dateTimeTextCntrl.text.isNotEmpty &&
                          checkinTextCntrl.text != null &&
                          checkinTextCntrl.text.isNotEmpty &&
                          checkOutTextCntrl.text != null &&
                          checkOutTextCntrl.text.isNotEmpty &&
                          locationTextCntrl.text != null &&
                          locationTextCntrl.text.isNotEmpty) {
                        _model.roomType.add(roomTypeTextCntrl.text);
                        _model.dateTime.add(dateTimeTextCntrl.text);
                        _model.checkIn.add(checkinTextCntrl.text);
                        _model.checkOut.add(checkOutTextCntrl.text);
                        _model.amount.add(widget.rent);
                        _model.days.add("1");
                        _model.location.add(locationTextCntrl.text);

                        await _model.saveData();

                        await _model.createStudentData();

                        roomTypeTextCntrl.clear();
                        dateTimeTextCntrl.clear();
                        checkinTextCntrl.clear();
                        checkOutTextCntrl.clear();
                        amountTextCntrl.clear();
                        daysControler.clear();
                        locationTextCntrl.clear();

                        setState(() {
                          _model.createStudentData();
                          _model.saveData();
                        });
                        showAlertDialog(context);
                      } else {
                        showAlerErrortDialog(context);
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 50),
                      child: Text("Confirm",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.green),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
              ),
              SizedBox(
                height: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Room Booking !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Are you sure to Book Room!!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Room Booking !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check your Enter Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
