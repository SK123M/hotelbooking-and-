import 'package:flutter/material.dart';
import 'package:hotel_clg/admin/create_room_model.dart';
import 'package:hotel_clg/admin/create_room_screen.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/user/view_room.dart';

class RoomsScreen extends StatefulWidget {
  final String login;

  RoomsScreen({super.key, required this.login});

  @override
  State<RoomsScreen> createState() => _RoomsScreenState();
}

class _RoomsScreenState extends State<RoomsScreen> {
  CreateRoomModel _roomModel = CreateRoomModel();

  List<String> roomType = [
    'Single Bed Room',
    'Double Bed Room',
    'Deluxe Rooms',
    'Luxury Rooms',
  ];

  List<String> locationlist = [
    'Chennai',
    'Vellore',
    'ECR - Chennai',
    'Bangalore',
  ];

  int selectLoc = 0;

  Future<void> _initData() async {
    await _roomModel.createRoom(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _roomModel
        .saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }

  List<String> image = [
    "assets/images/lxr.jpg",
    "assets/images/dr.jpg",
    "assets/images/dro.jpg",
    "assets/images/sr.jpg",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Our Rooms',
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
              onPressed: () {
                setState(() {
                  _roomModel.createRoom();
                  _roomModel.saveData();
                });
              },
              icon: Icon(Icons.replay_circle_filled_rounded)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (widget.login == "Admin")
            Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => CreateRoomScree()));
        },
        child: Icon(Icons.add_circle_outlined),
        tooltip: "Add Rooms",
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              ListView.builder(
                  primary: false,
                  shrinkWrap: true,
                  itemCount: _roomModel.camount.length,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Card(
                          color: Colors.white,
                          elevation: 13,
                          shadowColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: 150,
                                  width: 280,
                                  child: Image.asset(
                                    _roomModel.croomType == 'Single Bed Room'
                                        ? image[2]
                                        : _roomModel.croomType ==
                                                'Double Bed Room'
                                            ? image[3]
                                            : _roomModel.croomType ==
                                                    'Deluxe Rooms'
                                                ? image[1]
                                                : _roomModel.croomType ==
                                                        'Luxury Rooms'
                                                    ? image[0]
                                                    : image[0],
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      _roomModel.croomType[index],
                                      style: CommonStyles.blue14900(),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                /* Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Location",
                                      style: CommonStyles.blue14900(),
                                    ),
                                    Text(
                                      location[index],
                                      style: CommonStyles.blue14900(),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20,
                                ),*/
                                Text(
                                  _roomModel.cdes[index],
                                  style: CommonStyles.black12(),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    if (widget.login != "Admin")
                                      ElevatedButton(
                                          onPressed: () {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ViewRoomScreen(
                                                          title: _roomModel
                                                              .croomType[index],
                                                          rent: _roomModel
                                                              .camount[index],
                                                          image: image[index],
                                                          description:
                                                              _roomModel
                                                                  .cdes[index],
                                                          location: _roomModel
                                                              .clocation[index],
                                                        )));
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 10, horizontal: 10),
                                            child: Text("Book Room",
                                                style: CommonStyles
                                                    .whiteText15BoldW500()),
                                          ),
                                          style: ButtonStyle(
                                              backgroundColor:
                                                  MaterialStateProperty.all(
                                                      Colors.green),
                                              shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                      side: BorderSide(
                                                          color:
                                                              Colors.blue))))),

                                    if(widget.login == "Admin")    IconButton(onPressed: (){
                                      setState(() {
                                        _roomModel.removeDataAtIndex(index);
                                        
                                      });

                                    }, icon: Icon(Icons.delete,
                                    color: Colors.red,
                                      size: 26,
                                    ))

                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        )
                      ],
                    );
                  })
            ],
          ),
        ),
      ),
    );
  }
}
