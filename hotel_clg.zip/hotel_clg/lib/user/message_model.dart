import 'package:shared_preferences/shared_preferences.dart';

class MessageModel {
// Create Student

  List<String> name = [];
  List<String> emailid = [];
  List<String> sub = [];
  List<String> message = [];

  Future<void> createStudentData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name = prefs.getStringList('name') ?? [];
    emailid = prefs.getStringList('emailid') ?? [];
    sub = prefs.getStringList('sub') ?? [];
    message = prefs.getStringList('message') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('name', name);
    prefs.setStringList('emailid', emailid);
    prefs.setStringList('sub', sub);
    prefs.setStringList('message', message);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

    name.removeAt(index);
    emailid.removeAt(index);
    sub.removeAt(index);
    message.removeAt(index);

  }

}