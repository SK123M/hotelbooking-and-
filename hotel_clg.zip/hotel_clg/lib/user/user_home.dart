import 'package:flutter/material.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/user/about_screen.dart';
import 'package:hotel_clg/user/contact_screen.dart';
import 'package:hotel_clg/user/home_screen.dart';
import 'package:hotel_clg/user/rooms_screen.dart';
import 'package:titled_navigation_bar/titled_navigation_bar.dart';


class UserHome extends StatefulWidget {
  const UserHome({super.key});

  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {

  int bodyIndex = 0;
  List<Widget> body = [
    const HomeScreen(),
     RoomsScreen(login: "User"),
    const AboutScreen(),
    const ContactScreen(),
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: bodyIndex,
        children: body,
      ),
      bottomNavigationBar: buildBottomNavigationBar(),
    );
  }

  buildBody() {
    return body.elementAt(bodyIndex);
  }

  buildBottomNavigationBar() {
    return TitledBottomNavigationBar(
        activeColor: Colors.blue,
        inactiveColor: Colors.blue.shade900,
        height: 65,
        currentIndex: bodyIndex,
        onTap: (index) {
          setState(() {
            bodyIndex = index;
          });
        },
        items: [
          TitledNavigationBarItem(
            title: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.home),
                SizedBox(
                  height: 5,
                ),
                Text(
                  'Home'.toUpperCase(),
                  style: CommonStyles.black13(),
                ),
              ],
            ),
            icon: const Icon(Icons.home),
          ),
          TitledNavigationBarItem(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.meeting_room_sharp),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Rooms'.toUpperCase(),
                    style: CommonStyles.black13(),
                  ),
                ],
              ),
              icon: const Icon(Icons.meeting_room_sharp)),
          TitledNavigationBarItem(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.account_balance_outlined),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'About'.toUpperCase(),
                    style: CommonStyles.black13(),
                  ),
                ],
              ),
              icon: const Icon(Icons.account_balance_outlined)),
          TitledNavigationBarItem(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.contact_phone),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Contact'.toUpperCase(),
                    style: CommonStyles.black13(),
                  ),
                ],
              ),
              icon: const Icon(Icons.contact_phone)),
        ]);
  }
}
