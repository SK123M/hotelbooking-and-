import 'package:shared_preferences/shared_preferences.dart';

class CreateRoomModel {
// Create Student

  List<String> croomType = [];
  List<String> clocation = [];
  List<String> camount = [];
  List<String> cdays = [];
  List<String> cdes = [];

  Future<void> createRoom() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    croomType = prefs.getStringList('croomType') ?? [];
    clocation = prefs.getStringList('clocation') ?? [];
    cdays = prefs.getStringList('cdays') ?? [];
    camount = prefs.getStringList('camount') ?? [];
    cdes = prefs.getStringList('cdes') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('croomType', croomType);
    prefs.setStringList('clocation', clocation);

    prefs.setStringList('cdes', cdes);
    prefs.setStringList('cdays', cdays);
    prefs.setStringList('camount', camount);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

    croomType.removeAt(index);
    clocation.removeAt(index);
    cdes.removeAt(index);
    cdays.removeAt(index);
    camount.removeAt(index);

  }

}
