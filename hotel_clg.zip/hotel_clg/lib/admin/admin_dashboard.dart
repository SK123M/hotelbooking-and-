import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:hotel_clg/admin/enquire_screen.dart';
import 'package:hotel_clg/admin/rating_screen.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/login_screen.dart';
import 'package:hotel_clg/user/home_screen.dart';
import 'package:hotel_clg/user/rooms_screen.dart';

class AdminDashBoardScreen extends StatefulWidget {
  const AdminDashBoardScreen({super.key});

  @override
  State<AdminDashBoardScreen> createState() => _AdminDashBoardScreenState();
}

class _AdminDashBoardScreenState extends State<AdminDashBoardScreen> {
  final CarouselController controller = CarouselController();
  int activeIndex = 1;

  // int exploreIndex = 0;

  List<String> imageBanner = [
    'assets/images/dr.jpg',
    'assets/images/dro.jpg',
    'assets/images/h1.jpg',
    'assets/images/lxr.jpg',
    'assets/images/sr.jpg',
  ];

  List<String> name = [
    "Packages",
    "Bookings",
    "Enquiries",
    "Rate and Reviews",
  ];

  List<IconData> icon = [
    Icons.backpack,
    Icons.book,
    Icons.question_mark_outlined,
    Icons.star_rate_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Admin DashBoard',
          style: CommonStyles.blue18900(),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                      (route) => false, // Keep removing routes until this condition is met
                );
              },
              icon: Icon(
                Icons.login_outlined,
                color: Colors.white,
              )),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              CarouselSlider.builder(
                  carouselController: controller,
                  itemCount: imageBanner.length,
                  itemBuilder: (context, currentIndex, realIndex) {
                    return Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      height: 150,
                      margin: EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: Image.asset(
                            imageBanner[currentIndex],
                            fit: BoxFit.fill,
                          )),
                    );
                  },
                  options: CarouselOptions(
                    height: 200,
                    autoPlay: true,
                    pageSnapping: true,
                    autoPlayCurve: Curves.easeInOut,
                    // enableInfiniteScroll: false,
                    //  enlargeStrategy: CenterPageEnlargeStrategy.height,
                    //   viewportFraction: 1,
                    enlargeCenterPage: true,
                    //    initialPage: 0,
                    // aspectRatio: 16/9,
                    autoPlayInterval: Duration(seconds: 2),
                    onPageChanged: (index, reason) =>
                        setState(() => activeIndex = index),
                  )),
              SizedBox(
                height: 30,
              ),
              ListView.builder(
                  shrinkWrap: true,
                  primary: false,
                  itemCount: name.length,
                  itemBuilder: (context, index) {
                    return Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: InkWell(
                          onTap: () {
                            if (index == 0)
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => RoomsScreen(
                                    login: "Admin",
                                  )));


                            if (index == 1)
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => HomeScreen()));

                            if (index == 2)
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => EnquireScreen()));

                            if (index == 3)
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (context) => RatingScreen()));
                          },
                          child: Card(
                            color: Colors.white,
                            shadowColor: Colors.white,
                            elevation: 10,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 15, vertical: 15),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        name[index],
                                        style: CommonStyles.black15(),
                                      ),
                                      IconButton(
                                          onPressed: () {},
                                          icon: Icon(
                                            icon[index],
                                            size: 45,
                                            color: Colors.blueAccent,
                                          ))
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                        ));
                  })
            ],
          ),
        ),
      ),
    );
  }
}
