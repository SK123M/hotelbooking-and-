import 'package:flutter/material.dart';
import 'package:hotel_clg/common.dart';
import 'package:hotel_clg/login_screen.dart';

class LoginScreenDesign extends StatefulWidget {
  const LoginScreenDesign({super.key});

  @override
  State<LoginScreenDesign> createState() => _LoginScreenDesignState();
}

class _LoginScreenDesignState extends State<LoginScreenDesign> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage(
                  "assets/images/h1.jpg",
                ),
                fit: BoxFit.cover,
                opacity: 0.8)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [

            SizedBox(
              height: 40,
            ),
            Text(
              "Welcome to wow",
              style: CommonStyles.whiteText18BoldW500(),
            ),
            Text(
              "Do Come & Stay Blue Door".toUpperCase(),
              style: CommonStyles.whiteText28BoldW500(),
            ),
            ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(MaterialPageRoute(builder: (context)=> LoginScreen()));
                },
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 70),
                  child:
                      Text("View", style: CommonStyles.whiteText18BoldW500()),
                ),
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.0),
                            side: BorderSide(color: Colors.blue))))),

            SizedBox(
              height: 40,
            ),
          ],
        ),
      ),
    );
  }
}
