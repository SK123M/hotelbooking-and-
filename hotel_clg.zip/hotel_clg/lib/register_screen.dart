import 'package:flutter/material.dart';
import 'package:hotel_clg/common.dart';
import 'package:shared_preferences/shared_preferences.dart';


class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  final TextEditingController emailTextEditingController = TextEditingController();
  final TextEditingController fnameTextEditingController = TextEditingController();
  final TextEditingController lnameTextEditingController = TextEditingController();
  final TextEditingController passwordTextEditingController =
  TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage(
                  "assets/images/h1.jpg",
                ),
                fit: BoxFit.cover,
                opacity: 0.8)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.electric_bolt_outlined,
                  color: Colors.white,
                  size: 45,
                ),
                SizedBox(
                  width: 30,
                ),
                Text(
                  "Create New Account",
                  style: CommonStyles.whiteText28BoldW500(),
                )
              ],
            ),
            Column(
              children: [

                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: Colors.white,

                  ),
                  child: TextFormField(

                    controller: fnameTextEditingController,
                    style: CommonStyles.black15(),
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "First Name",
                      labelText: "First Name",
                      labelStyle: CommonStyles.black15(),
                      hintStyle: CommonStyles.black15(),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ), Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: Colors.white,

                  ),
                  child: TextFormField(

                    controller: lnameTextEditingController,
                    style: CommonStyles.black15(),
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "Last Name",
                      labelText: "Last Name",
                      labelStyle: CommonStyles.black15(),
                      hintStyle: CommonStyles.black15(),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ),

                SizedBox(
                  height: 30,
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: Colors.white,

                  ),
                  child: TextFormField(

                    controller: emailTextEditingController,
                    style: CommonStyles.black15(),
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "E - Mail ID",
                      labelText: "E - Mail ID",
                      labelStyle: CommonStyles.black15(),
                      hintStyle: CommonStyles.black15(),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    color: Colors.white,

                  ),
                  child: TextFormField(
                    style: CommonStyles.black15(),
                    controller: passwordTextEditingController,
                    obscureText: true,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      hintText: "Password",
                      labelText: "Password",
                      labelStyle: CommonStyles.black15(),
                      hintStyle: CommonStyles.black15(),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.white),
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                ),
              ],
            ),
            Column(
              children: [
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        if (fnameTextEditingController.text.isNotEmpty &&
                        lnameTextEditingController.text.isNotEmpty &&
                        emailTextEditingController.text.isNotEmpty &&
                        passwordTextEditingController.text.isNotEmpty
                        ) {
                          saveUserData();
                          showAlertDialog(context);
                        } else {
                          showAlerErrortDialog(context);
                        }
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 70),
                      child: Text("Register Now",
                          style: CommonStyles.whiteText18BoldW500()),
                    ),
                    style: ButtonStyle(
                        backgroundColor:
                        MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),
                SizedBox(
                  height: 10,
                ),

              ],
            )
          ],
        ),
      ),
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create New Account !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check Entered Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Create New Account !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Your Account has Created !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  SharedPreferences? sharedPreferences;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      setState(() {
        sharedPreferences = prefs;
      });
    });
  }
  void saveUserData() {
    sharedPreferences!.setString('username', fnameTextEditingController.text);
    sharedPreferences!.setString('email', emailTextEditingController.text);
    sharedPreferences!.setString('password', passwordTextEditingController.text);
  }
}
